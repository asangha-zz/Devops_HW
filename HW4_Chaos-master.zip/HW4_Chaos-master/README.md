# HW4_Chaos

The entire experiment with setup,analysis and disabling the link is automated through chaos_setup_experiment.yml  
The experiment has been analayzed over 1000 requests to get better analysis  


### REPORT :   
https://github.ncsu.edu/asangha/HW4_Chaos/blob/master/Report_Devops.pdf


### SCREENCAST :
http://youtu.be/DMz0annFpoA?hd=1


### SET_UP
  
  1) Clone the repository                                                                                  
      git clone https://github.ncsu.edu/asangha/HW4_Chaos.git  

  2) Run playbook “chaos_experiment_setup.yml” to bring up the chaos experiment setup                                                     
     <b>ansible-playbook chaos_experiment_setup.yml -i inventory</b>                                                                              
  a) The playbook will bring up the 5 server.  
  b) Proxy server (To route to api of one of the 3 server based on probabilities), 3 servers (Api, api-control && api-experiment) The three      have the same code and can be seen in main.js. And also the ratings server. (Which this Api will call to).  
  c)  The playbook will also disable the link from experiment server to the ratings server with the help of iptables. The link can be    r       renabled by deleting the iptables rule.  
  d) <b>Playbook will now run 1000 wget request to proxy server ip/api (using automation bash script) and will record the responses in log file which can be seen under Analysis folder.</b>  
  e) After the experiment has been performed, the playbook will go through the logfiles to see whether the api gracefully handed the f          failure of api service or not. A report will be generated  
  
  3) Sample report file can be seen in  
  https://github.ncsu.edu/asangha/HW4_Chaos/blob/master/analysis_report  
   "Successful Fallbacks Served by API (Rating Server was Down, Generalized Web page)" indicates the requests handled by API itself when Rating Server was down or threw an error. In the sample report it shows 6.  
  "Successful Requests Served by API through Ratings API Control" indicates requests served successfully when it went through API Control  
  "Total Requests To experiment API" indicates requests that went to experiement API  
  (Since we are using probabilities)  
  <b>Here Last line indicates whether all requests were handled gracefully "API handled all requests sucessfully"</b>  
  

  4) The link between api-experimenttal and ratings server is being implemented with the help of IPTables  
  iptables -A INPUT -j DROP --source 192.168.11.91  
  192.168.11.91 is the IP of exp server
  The link can be brought back using  
  iptables -D INPUT 1  
  <b>This step is automatically done using Ansible Playbook</b>  
  
  5) To see, how the ratings page look, just Hit the *proxy server ip* : *proxy server port* / api . 1000 requests have already been hit with the help  of code automation as explained in 2 d.  
  
  
  ### PURPOSE OF EACH FILE  
  Analysis: For Storing the Log Files of each server,log files  
  node_modules and test : Can be ignored  
  analysis_log : Bash script to determine if API handled success/fail gracefully  
  analysis_report: Report generated after experiment is completed  
  automation: Bash script to generate 1000 http request to proxy server  
  chaos_setup_experiement.yml: Master playbook that will automate the whole experiment with the help of these files
  main.js: Contains /api endpoint. Playbook will create 3 servers by using main.js (API,API-COntrol and API-exp)  
  proxy.js: Will redirect to one of the servers /api  
  ratings.js: Will return 500 or 200 
  
  ### DIFFICULTIES FACED  
  1) Coming up with strategy to disable connectio to ratings microservice
  2) Getting the status of redirected code or follow the redirect  
  
  
  
  
  
  
  
  
  
  
  
  
