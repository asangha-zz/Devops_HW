// Source : MileStone 3 : Pollloadbalancer.js (The one used for canary)
var fs = require('fs');
var express = require('express');
var request = require('request');
var httpProxy = require('http-proxy');
var Random = require('random-js');

var random = new Random(Random.engines.mt19937().autoSeed());
var proxy   = httpProxy.createProxyServer({});
var app = express();

var alertFlag = false;

///////////// WEB ROUTES

// Add hook to make it easier to get all visited URLS.
app.use(function(req, res, next) {
  console.log(req.method, req.url);
  console.log("AlertFlag Status: ", alertFlag);
  var serverFulfillingReq;
  if(random.bool(0.99)) {
     
    serverFulfillingReq = "192.168.11.90:3000";  
  } else {
    if(random.bool(0.5)){
        serverFulfillingReq = "192.168.11.90:3001";  
    }
    else{
        serverFulfillingReq = "192.168.11.91:3002"; 
    }
    
  }
  console.log("Server Fulfilling Request: http://"+serverFulfillingReq+"/");
  proxy.web(req, res, {target: "http://"+serverFulfillingReq });
});



// HTTP SERVER
var server = app.listen(3003, function () {

    var host = server.address().address
    var port = server.address().port
  
    console.log('Example app listening at http://%s:%s', host, port)
  
 
});
