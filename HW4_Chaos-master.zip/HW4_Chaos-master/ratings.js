var redis = require('redis')
var multer  = require('multer')
var express = require('express')
var fs  = require('fs')
var app = express()
var rp = require('request-promise');

app.use(function(req, res, next) 
{
	console.log(req.method, req.url, req.connection.Port);

	// ... INSERT HERE.
	next(); // Passing the request to the next handler in the stack.
});

app.get('/ratings', function(req, res) {
	{       
    //console.log('Ratings at http://%s', PORT)
    res.status(200);
    res.writeHead(200, {'content-type':'text/html'});
    res.write("<h3>Ratings Success Request Served</h3>");
    res.end();
    
	}
})

var server = app.listen(3010, function () {

  var host = server.address().address
  var port = server.address().port

  console.log('Example app listening at http://%s:%s', host, port)
})
