//var redis = require('redis')
var multer  = require('multer')
var express = require('express')
var fs  = require('fs')
var app = express()
var rp = require('request-promise');

// REDIS
//var client = redis.createClient(6379, '127.0.0.1', {})

///////////// WEB ROUTES

// Add hook to make it easier to get all visited URLS.
app.use(function(req, res, next) 
{
	console.log(req.method, req.url );

	// ... INSERT HERE.
	next(); // Passing the request to the next handler in the stack.
});


app.get('/api', function(req, res1) {
	{
    // console.log('Redirecting at http://%s', PORT)
    // console.log(req.url)
    // res.redirect('/ratings');    
  rp.get({
      uri: 'http://192.168.11.10:3010/ratings',
      //resolveWithFullResponse: true
      timeout: 1000  
  }).then(function(res){

    //console.log(res);
    console.log('Ratings at success')
    res1.writeHead(200, {'content-type':'text/html'});
    res1.write("<h3>Ratings Success Request Served</h3>");
    res1.write("Welcome Ami")
    res1.write("<h3>Please rate thumbs up or thumbs down for recently watched movies or shows</h3>");
    res1.write("<h3> HIMYM Thumbs Up Thumbs Down (95% Liked this Show) </h3>")
    res1.write("<h3>Justice League Thumbs Up Thumbs Down (99% Liked this Movie)</h3>")
    //return res;
    res1.end();
  })
  .catch(function(err){
      // var respErr  = JSON.parse(err.error);
      // var errorResult = {
      //     origUrl: respErr.origUrl,
      //     error: respErr
      // };
      
      // results.push(errorResult);

      console.log(err);
      console.log('Ratings at catch')
      res1.writeHead(200, {'content-type':'text/html'});
      res1.write("<h3>Ratings Fallback Request Served</h3>");
      res1.write("<h3>Here are the ratings of general movies you might want to watch</h3>");
      res1.write("<h3>THOR 99% liked this movie</h3>")
      //return res;
      res1.end();

  });



	}
})

app.get('/ratings', function(req, res) {
	{

    console.log('Ratings at http://%s', PORT)
    res.status(500);
    res.writeHead(500, {'content-type':'text/html'});
    res.write("<h3>Ratings Fallback Request Served</h3>");
   res.end();
    
	}
})


app.get('/', function(req, res) {
  
	{

    console.log('Example appserver listening at http://%s:%s', PORT)
		res.writeHead(200, {'content-type':'text/html'});
    res.write("<h3>test</h3>");
   		res.end();
	}
})


var PORT=process.argv[2];

// HTTP SERVER
var server = app.listen(PORT, function () {

  var host = server.address().address
  var port = server.address().port

  console.log('Example app listening at http://%s:%s', host, port)
})




