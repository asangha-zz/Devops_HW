Proxies, Queues, Cache Fluency.

ScreenCast Link : http://youtu.be/pluLDAeLw7o?hd=1
<br>
In the screencast, I have forgot to mention that the time being shown is in milliseconds.
Have added "Time taken in milliseconds" to the code after the screencast was taken
<br>
Catfact/1 will return the 1st line
<br>
/recent will return the top 5 visitd websites including recent


---------------------------------------------------------------------------------------------------

Set up instructions
<br>
1)git clone https://github.ncsu.edu/asangha/HW3
2)cd HW3
3)sudo npm install
4)node main.js

For Testing upload and meow functionality
curl -F "image=@./img/morning.jpg" localhost:3000/upload

-------------------------------------------------------------------------------------------------------

Conceptual Questions
Benefits and Issues Related to Feature Flags

Benefits of Feature Flags:
1) If the feature performs poorly, it can be quickly turned off and removed
2) There might be two features, (Simple example, font size 10 and font size 11) and you just want to see which feature is better. The feature which is not appealing can be turned off.
3) Do phased rollout of the new feature so as to smoothly blend the new feature to everyone while ensuring there are no scalability issues.
4) New feature may be deployed and evalated in production for several months before being publically released. Thus the advantage here is engineer can stabilize chunks of feature with the benefit of having access to actual production services for testing

<br>
There might be various issues related to feature flags
1) They are technical debt
2) There is much complexity with running multiple versions of same thing in parallel with only one version being visible to customer at given time. 
3) Old retired flags must be removed from the codebase
4) Adding more flags makes testing difficult. It is difficult to tell which flags are necessary or obsolete.
5) User might use feature differently than devs expected
6) Removing Flags is highly variable practice. It is very hard to test deployment and impact.

------------------------------------------------------------------------------------

What are some reasons for keeping servers in seperate availability zones?
1) Load balancing
2) Switch requests when deploying new version
3) If one instance fails, switch it to other to handle requests(Fault tolerant)
4)) Reduced access times
5) Have environments resilient to pollution
6) Avoiding slow spin up

--------------------------------------------------------------------------------------

Describe the Circuit Breaker pattern and its relation to operation toggles.
Source : https://martinfowler.com/bliki/CircuitBreaker.html
1) The basic idea behind Circuit  Breaker pattern is that you wrap a protected function call in circuit breaker object and monitor for failures.
2) If the no of failures reach a certain threshold, the circuit breaker trips and all further calls return with error, without protected call being made at all.
3) There might be some kind of monitor alert if the circuit breaker trips.
This pattern is to protect the application from total failure if any external service goes down. Suitable for applications that use or rely on data and connectivity to external services
<br>
Relation to Operation Toggles: To control operational aspects of system's behaviour.
For eg : 1) There might be operations toggle that disable many non-critcal features in website prior to high-demand product launch
2) Disabling recommendations panel on homepage when website is under heavy load.

-------------------------------------------------------------------------------------------


What are some ways you can help speed up an application that has
a) traffic that peaks on Monday evenings
<br>
--> More servers to handle increased requests (not cost effective)
<br>
--> AutoScaling Scale up Ec2 instances to handle more requests and scale down when not needed through scripts (cost effective)
<br>
--> Cache the frequently accessed data
<br>
--> Load balance the requests among various servers

b) real time and concurrent connections with peers
<br>
--> Load Balancing of requests 
<br>
--> Keep different servers in different availability zones, request should be served by the nearest server so as to reduce latency

c) heavy upload traffic
<br>
--> Zip up the traffic during retrieval and delivery (Compress the data)
<br>
--> Use Queues
