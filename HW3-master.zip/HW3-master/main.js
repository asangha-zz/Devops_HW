var redis = require('redis')
var multer  = require('multer')
var express = require('express')
var fs      = require('fs')
var app = express()
// REDIS
var client = redis.createClient(6379, '127.0.0.1', {})
var x=1

app.use('/uploads', express.static(__dirname+'/uploads'));


function get_line(filename, line_no) {
    var data = fs.readFileSync(filename, 'utf8');
    var lines = data.split("\n");

    if(+line_no > lines.length){
      throw new Error('File end reached without finding line');
	}
	else{
		return lines[line_no];
	}

    //callback(null, lines[+line_no]);
}

///////////// WEB ROUTES

// Add hook to make it easier to get all visited URLS.
app.use(function(req, res, next) 
{
	console.log(req.method, req.url);

	// ... INSERT HERE.
	client.lpush("recents",req.url,function(err){
		client.ltrim("recents",0,4, function(status){
			next(); // Passing the request to the next handler in the stack.
		})
	}
)
	
});


app.post('/upload',[ multer({ dest: './uploads/'}), function(req, res){
   console.log(req.body) // form fields
   console.log(req.files) // form files

   if( req.files.image )
   {
	   fs.readFile( req.files.image.path, function (err, data) {
	  		if (err) throw err;
	  		var img = new Buffer(data).toString('base64');
			console.log(img);
			//client.lpush("cat",img);
			  
			client.lpush('cat', img, function(err)
			{
         
			res.status(204).end()
			});
		});
	}
}]);

app.get('/toggleCacheFeature', function(req,res){
	res.writeHead(200, {'content-type':'text/html'});
	if(x === 1){
		x=0;
		res.write("Turning off cache feature");
	    res.status(204).end()
		
	}else{
		x=1;
		res.write("Turning on cache feature");
		res.status(204).end()
	}
	

})

app.get('/meow', function(req, res) {
	
		client.lpop('cat', function(err,imagedata){
			console.log(err || imagedata)
			if (err) throw err
			res.writeHead(200, {'content-type':'text/html'});
			res.write("<h1>\n<img src='data:my_pic.jpg;base64,"+imagedata+"'/>");
		   res.end();
		})
	
	
})

app.get('/catfact/:num', function(req, res) {

	res.writeHead(200, {'content-type':'text/html'});
	
	
	var numr = req.params.num-1
	var start = new Date();	
	//var t0 = performance.now();

	if(x === 1){
		//var start = new Date();	
			
		var keyname="catfact:"+ numr;
		client.get(keyname, function(err,value){
				if(value != null){
                    var t = process.hrtime();	
					client.get(keyname, function(err, value){
						//console.log("Retriving value from key");
						t = process.hrtime(t);
						res.write(value);
						var time = new Date() - start;
						
						//console.log("Time Date"+ t[1]/1000);
						res.write(`<h3>${t[1]/1000000}</h3>`);
						res.write("Retrieve value from key/cache");
						res.status(204).end();
						//res.end();
					})
									
					
				}
				else {
					var t = process.hrtime();	
					console.log("Setting the value");
					client.set(keyname, get_line("catfacts.txt",numr), function(err, value) {	
						client.expire(keyname, 10, function(err, value) {	
							res.write(get_line("catfacts.txt",numr));
							var time = new Date() - start;
							
							t = process.hrtime(t);
							//console.log("Time Date"+ t[1]/1000);
							res.write(`<h3>${t[1]/1000000}</h3>`);
							res.write("Key expired or not yet created, read from txt");
							
							res.status(204).end();
						});						
					});


				}
				//res.write(value);
		})
		
	}

	else {
		
		
		
		var t = process.hrtime();
		//console.log(get_line("catfacts.txt",numr));	
		res.write(get_line("catfacts.txt",numr));
		t = process.hrtime(t);
		//console.log(t[0],t[1]);
		//var time2= t1 - t0;
		//console.log("Time Date"+ t[1]/1000);
		res.write(`<h3>${t[1]/1000000}</h3>`);
		res.write("Toggle feature off, read from text");
		res.status(204).end();

	}
	
    	
})



app.get('/recent', function(req, res) {
	client.lrange("recents",0,-1,function(err,recentsites)
	{
	  console.log(recentsites);
	  res.send(recentsites);
	});
})

app.get('/test', function(req, res) {
	{	
		res.writeHead(200, {'content-type':'text/html'});
		res.write("<h3>test1</h3>");
   		res.end();
	}
})

app.get('/get', function(req, res) {
	client.get("myexpiringkey", function(err, value) {
		client.ttl("myexpiringkey", function(err, ttl) {
			if(value != null){
				res.writeHead(200, {'content-type':'text/html'});
				res.write(`<h3>Key Name myexpiringkey Value : ${value} -TTL ${ttl}</h3>`);
				res.end();
			}
			else{
				res.writeHead(200, {'content-type':'text/html'});
				res.write("The key has expired");
				res.end();
			}
				
		});
	});
})

app.get('/set', function(req, res) {
	client.set("myexpiringkey", "seconds to live", function(err, value) {	
		client.expire("myexpiringkey", 10, function(err, ttl) {	
			res.writeHead(200, {'content-type':'text/html'});
			res.write(`<h3>This key will expire in 10 seconds</h3>`);
			res.end();

		 
		});	
		
		
		
	});
})
 
// HTTP SERVER
var server = app.listen(3000, function () {

  var host = server.address().address
  var port = server.address().port

  console.log('Example app listening at http://%s:%s', host, port)
})

exports 
