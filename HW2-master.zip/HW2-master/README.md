Instructions :

1)Clone this repository

2)cd HW2

3)sudo npm install

4)node main.js subject.js

5)node_modules/.bin/istanbul cover test.js

<b> Coverage Report </b>

<img width="960" alt="mystery" src="https://media.github.ncsu.edu/user/7531/files/f9448962-afb0-11e7-9ccb-493caf2045ed">

<img width="960" alt="subject" src="https://media.github.ncsu.edu/user/7531/files/510ee3e0-afb1-11e7-9048-beade5df1a46">
