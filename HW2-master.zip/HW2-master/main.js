var esprima = require("esprima");
var options = {tokens:true, tolerant: true, loc: true, range: true };
var faker = require("faker");
var fs = require("fs");
faker.locale = "en";
var mock = require('mock-fs');
var _ = require('underscore');
var Random = require('random-js');

function main()
{
	var args = process.argv.slice(2);

	if( args.length == 0 )
	{
		args = ["subject.js"];
	}
	var filePath = args[0];

	constraints(filePath);

	generateTestCases()

}

var engine = Random.engines.mt19937().autoSeed();

function createConcreteIntegerValue( greaterThan, constraintValue )
{
	if( greaterThan )
		return Random.integer(constraintValue,constraintValue+10)(engine);
	else
		return Random.integer(constraintValue-10,constraintValue)(engine);
}

function Constraint(properties)
{
	this.ident = properties.ident;
	this.expression = properties.expression;
	this.operator = properties.operator;
	this.value = properties.value;
	this.altvalue = properties.altvalue;
	this.funcName = properties.funcName;
	// Supported kinds: "fileWithContent","fileExists"
	// integer, string, phoneNumber
	this.kind = properties.kind;
}

function fakeDemo()
{
	console.log( faker.phone.phoneNumber() );
	console.log( faker.phone.phoneNumberFormat() );
	console.log( faker.phone.phoneFormats() );
}

var functionConstraints =
{
}

var mockFileLibrary = 
{
	pathExists:
	{
		'path/fileExists': {}
	},

	fileWithContent:
	{
		pathContent: 
		{	
			  file1: 'text content',
			  file2: ''
		}
	},	
	
	fileExists:{
		pathContent: 
		{	
  			
		}
	},
	fileExistsWithEmptyContent:{
		pathContent: 
		{	
			file1: '',
		}
	}
};

function initalizeParams(constraints)
{
	var params = {};
	
	// initialize params
	for (var i =0; i < constraints.params.length; i++ )
	{
		var paramName = constraints.params[i];
		params[paramName] = '\'\'';
	}
	return params;	
}

// Source StackOverflow
https://stackoverflow.com/questions/12303989/cartesian-product-of-multiple-arrays-in-javascript
function permutations(list) {
    return _.reduce(list, function(a, b) {
        return _.flatten(_.map(a, function(x) {
            return _.map(b, function(y) {
                return x.concat([y]);
            });
        }), true);
    }, [ [] ]);
};

function fillParams(constraints,params,property)
{
	// plug-in values for parameters
	var modevars=[];
	console.log(constraints.length);
	for( var c = 0; c < constraints.length; c++ )
	{
		var constraint = constraints[c];
		//console.log("Constraint"+constraint.ident);
		//console.log("Constraint pro"+ constraint[property]);
		if( params.hasOwnProperty( constraint.ident ) )
		{
			if(constraint.ident == "mode"){
				modevars.push(constraint[property]);
				console.log(modevars);
	  }
			params[constraint.ident] = constraint[property];
			
		}
	}

	return modevars;
}


function generateTestCases()
{

	var content = "var subject = require('./subject.js')\nvar mock = require('mock-fs');\n";
	for ( var funcName in functionConstraints )
	{

		var params = initalizeParams(functionConstraints[funcName])
		var altparams = initalizeParams(functionConstraints[funcName])
		
		
		var constraints = functionConstraints[funcName].constraints;
		
		var fileWithContent = _.some(constraints, {kind: 'fileWithContent' });
		var pathExists      = _.some(constraints, {kind: 'fileExists' });

		// All the mode values permuted here
		var temp1=fillParams(constraints,params,"value")
		// All the mode alternate values permuted here
		var temp2=fillParams(constraints,altparams,"altvalue")
				
		console.log("ALT",altparams)
		console.log("P",params)

		// Prepare function arguments.
		var args = Object.keys(params).map( function(k) {return params[k]; }).join(",");
		var altargs = Object.keys(altparams).map( function(k) {return altparams[k]; }).join(",");

		console.log("Hey"+Object.keys(params));

		// Generate all the parameters
		var paramlist = Object.keys(params).map( function(x) { return params[x] } );
		var altparamlist = Object.keys(altparams).map( function(x) { return altparams[x] } );

		var arrayLength = paramlist.length;
		console.log("Hello"+paramlist.length);
		var newarray=[];
		for (var i = 0; i < arrayLength; i++) {
			//console.log(paramlist[i]);
			//console.log(altparamlist[i]);
			var cons = [paramlist[i],altparamlist[i]] ;
			
			if(i==3){
				cons=cons.concat(temp1);
				//console.log(cons);
				//console.log("Here"+ temp1);
				cons=cons.concat(temp2);
			}

			newarray.push(cons);
			//Do something
		}

		permuation1=permutations(newarray);
		console.log(permuation1);

		var phonecontains = _.contains(functionConstraints[funcName].params, "phoneNumber");

	    for (var i=0; i< permuation1.length; i++) {
			
			if(funcName != "fileTest"){
				content += "subject.{0}({1});\n".format(funcName, permuation1[i] ); 
				//console.log("Here"+content);
			}
			
		
		}

		if( pathExists || fileWithContent )
		{

			for (var i=0; i< permuation1.length; i++) {
				
				if(funcName == "fileTest"){
					var argst = permuation1[i].join(',');
					console.log("Here"+argst);
				

			if (argst != "'',''")
			{
			
			content += generateMockFsTestCases(pathExists,fileWithContent,funcName, argst);
			// Bonus...generate constraint variations test cases....
			content += generateMockFsTestCases(!pathExists,fileWithContent,funcName, argst);
			content += generateMockFsTestCases(pathExists,!fileWithContent,funcName, argst);
			content += generateMockFsTestCases(!pathExists,!fileWithContent,funcName, argst);
			}
		}
	}}
		else if (phonecontains){
			for( allparams in params )
			{
			
				if(allparams.indexOf("options") > -1)
				{
					params[allparams] = JSON.stringify(options);
				}
				if(allparams.indexOf("phoneNumber") > -1)
				{
					params[allparams] = "\""+faker.phone.phoneNumberFormat()+"\"";
				}
				
			}
			args = _.map(params, function(value, key, list){return value;}).join(",");
			content += "subject.{0}({1});\n".format(funcName, args ); 
			content += "subject.{0}({1});\n".format(funcName, altargs );

			var digitsno=[0,1,2,3,4,5,6,7,8,9];
			var phoneDigits=[digitsno,digitsno,digitsno];
			numberListPermutations = permutations(phoneDigits)
			//console.log("Permuation nos"+numberListPermutations);
			for (var i=0; i< numberListPermutations.length; i++) {
				//create dummy entries where first 3 digits are generated by permutations function appended by static value 9999999
				var phoneNumberRandom = "'" + numberListPermutations[i].toString().split(',').join('') + "999999'";
				params["phoneNumber"] = phoneNumberRandom
				if(options)
				{
					params["options"] = "'fake'"
				}

				var args = Object.keys(params).map( function(k) {return params[k]; }).join(",");
				content += "subject.{0}({1});\n".format(funcName, args );
			}

			

		}
		else
		{

			//console.log( altargs )
			// Emit simple test case.
			content += "subject.{0}({1});\n".format(funcName, args );
			content += "subject.{0}({1});\n".format(funcName, altargs );
		}

	}


	fs.writeFileSync('test.js', content, "utf8");

}

function generateMockFsTestCases (pathExists,fileWithContent,funcName,args) 
{
	var testCase = "";
	// Build mock file system based on constraints.
	var mergedFS = {};
	if( pathExists )
	{
		for (var attrname in mockFileLibrary.pathExists) { 
			console.log("Attrname"+attrname);
			console.log(mockFileLibrary.pathExists[attrname]);
			mergedFS[attrname] = mockFileLibrary.pathExists[attrname]; }
	}
	if( fileWithContent )
	{
		for (var attrname in mockFileLibrary.fileWithContent) { mergedFS[attrname] = mockFileLibrary.fileWithContent[attrname]; }
	}

	testCase += 
	"mock(" +
		JSON.stringify(mergedFS)
		+
	");\n";

	testCase += "\tsubject.{0}({1});\n".format(funcName, args );
	console.log(testCase);
	testCase+="mock.restore();\n";
	return testCase;
}

function constraints(filePath)
{
   var buf = fs.readFileSync(filePath, "utf8");
	var result = esprima.parse(buf, options);
	var randomString = "\'ami\'";

	traverse(result, function (node) 
	{
		//console.log(node.type);
		if (node.type === 'FunctionDeclaration') 
		{
			var funcName = functionName(node);
			console.log("Line : {0} Function: {1}".format(node.loc.start.line, funcName ));

			var params = node.params.map(function(p) {return p.name});

			functionConstraints[funcName] = {constraints:[], params: params};

			// Check for expressions using argument.
			traverse(node, function(child)
			{
				//console.log(child.type);


				if( child.type === 'BinaryExpression' && child.operator == "==")
				{   

					if( child.left.type == 'Identifier' && params.indexOf( child.left.name ) > -1)
					{
						// get expression from original source code:
						
						var expression = buf.substring(child.range[0], child.range[1]);
						var rightHand = buf.substring(child.right.range[0], child.right.range[1])

						 
						if(! isNaN(rightHand)) {
							functionConstraints[funcName].constraints.push( 
								new Constraint(
								{
									ident: child.left.name,
									value: rightHand,
									altvalue: !rightHand,
									funcName: funcName,
									kind: "integer",
									operator : child.operator,
									expression: expression
								}));

								
								
								
								

						}
						else if(typeof(rightHand)=="string"){
							functionConstraints[funcName].constraints.push( 
								new Constraint(
								{
									ident: child.left.name,
									value: rightHand,
									altvalue: randomString,
									funcName: funcName,
									kind: "string",
									operator : child.operator,
									expression: expression
								}));
						}
							

						
					}
				}


				else if( child.type === 'BinaryExpression' && child.operator == "!=")
				{
					if( child.left.type == 'Identifier' && params.indexOf( child.left.name ) > -1)
					{
						// get expression from original source code:
						var expression = buf.substring(child.range[0], child.range[1]);
						var rightHand = buf.substring(child.right.range[0], child.right.range[1])
						 
						if(! isNaN(rightHand)) {
							functionConstraints[funcName].constraints.push( 
								new Constraint(
								{
									ident: child.left.name,
									value: !rightHand,
									altvalue: rightHand,
									funcName: funcName,
									kind: "integer",
									operator : child.operator,
									expression: expression
								}));
						}
						else if(typeof(rightHand)=="string"){
							functionConstraints[funcName].constraints.push( 
								new Constraint(
								{
									ident: child.left.name,
									value: rightHand,
									altvalue: randomString,
									funcName: funcName,
									kind: "string",
									operator : child.operator,
									expression: expression
								}));
						}
							

						
					}
				}


				else if( child.type === 'BinaryExpression' && child.operator == "<" )
				{
					if( child.left.type == 'Identifier' && params.indexOf( child.left.name ) > -1)
					{
						// get expression from original source code:
						var expression = buf.substring(child.range[0], child.range[1]);
						var rightHand = buf.substring(child.right.range[0], child.right.range[1])

						functionConstraints[funcName].constraints.push( 
							new Constraint(
							{
								ident: child.left.name,
								value: parseInt(rightHand) - 1,
								altvalue: parseInt(rightHand) +1,
								funcName: funcName,
								kind: "integer",
								operator : child.operator,
								expression: expression
							}));
							
					}
				}


				else if( child.type === 'BinaryExpression' && child.operator == ">" )
				{
					if( child.left.type == 'Identifier' && params.indexOf( child.left.name ) > -1)
					{
						// get expression from original source code:
						var expression = buf.substring(child.range[0], child.range[1]);
						var rightHand = buf.substring(child.right.range[0], child.right.range[1])

						functionConstraints[funcName].constraints.push( 
							new Constraint(
							{
								ident: child.left.name,
								value: parseInt(rightHand) - 1,
								altvalue: parseInt(rightHand) +1,
								funcName: funcName,
								kind: "integer",
								operator : child.operator,
								expression: expression
							}));
					}
				}
			

				if(child.type === 'BinaryExpression' && child.left.type == 'CallExpression' ) {
					
										var leftChild = child.left;
										var expression = buf.substring(child.range[0], child.range[1]);
										if(leftChild.callee && leftChild.callee.property.name == "indexOf") {
											console.log("Heyloo");
											var fixed = "\"" +  leftChild.arguments[0].value + "\"";
											functionConstraints[funcName].constraints.push( 
												new Constraint(
												{
													ident: leftChild.callee.object.name,
													// A fake path to a file
													value: fixed ,
													altvalue: randomString,
													funcName: funcName,
													kind: "string",
													operator : child.operator,
													expression: expression
												}));
												
										}
					
									}
				

				else if( child.type == "CallExpression" && 
					 child.callee.property &&
					 child.callee.property.name =="readFileSync" )
				{
					for( var p =0; p < params.length; p++ )
					{
						if( child.arguments[0].name == params[p] )
						{
							functionConstraints[funcName].constraints.push( 
							new Constraint(
							{
								ident: params[p],
								value:  "'pathContent/file1'",
								altvalue: "'pathContent/file2'",
								funcName: funcName,
								kind: "fileWithContent",
								operator : child.operator,
								expression: expression
							}));
						}
					}
				}

				else if( child.type == "CallExpression" &&
					 child.callee.property &&
					 child.callee.property.name =="existsSync")
				{
					for( var p =0; p < params.length; p++ )
					{
						if (params[0]=="dir"){
						if( child.arguments[0].name == params[p] )
						{
							functionConstraints[funcName].constraints.push( 
							new Constraint(
							{
								ident: params[p],
								// A fake path to a file
								value:  "'path/fileExists'",
								altvalue: "'pathContent'",
								funcName: funcName,
								kind: "fileExists",
								operator : child.operator,
								expression: expression
							}));
						}
					}	

					else if (params[0]=="filePath"){
						
													if( child.arguments[0].name == params[p] )
													{
														functionConstraints[funcName].constraints.push( 
														new Constraint(
														{
															ident: params[1],
															// A fake path to a file
															value:  "'path/fileExists'",
															altvalue: "'pathContent'",
															funcName: funcName,
															kind: "fileExists",
															operator : child.operator,
															expression: expression
														}));
														
													}
												}
					
					}
				}

	

			});


			//console.log( functionConstraints[funcName]);

		}
	});
}

function traverse(object, visitor) 
{
    var key, child;

    visitor.call(null, object);
    for (key in object) {
        if (object.hasOwnProperty(key)) {
            child = object[key];
            if (typeof child === 'object' && child !== null) {
                traverse(child, visitor);
            }
        }
    }
}

function traverseWithCancel(object, visitor)
{
    var key, child;

    if( visitor.call(null, object) )
    {
	    for (key in object) {
	        if (object.hasOwnProperty(key)) {
	            child = object[key];
	            if (typeof child === 'object' && child !== null) {
	                traverseWithCancel(child, visitor);
	            }
	        }
	    }
 	 }
}

function functionName( node )
{
	if( node.id )
	{
		return node.id.name;
	}
	return "";
}


if (!String.prototype.format) {
  String.prototype.format = function() {
    var args = arguments;
    return this.replace(/{(\d+)}/g, function(match, number) { 
      return typeof args[number] != 'undefined'
        ? args[number]
        : match
      ;
    });
  };
}

main();
exports.main = main;