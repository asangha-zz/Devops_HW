# HW1
<br>Ami Sanghavi
<br>asangha
<br>200129489

Setup:

Here I have divided into two plays for better reusability:
<br>configure.yml : This will set the Ubuntu 16:04 for basic setup with Vagrant, VirtualBox and PhpvirtualBox installed in it 
<br>provision.yml : For Provisioning VM providing VCL like interface

Steps :

<br>1)Clone the git repo on your host machine:
https://github.ncsu.edu/asangha/HW1.git
<br>2)Rename keys/node0.key and IP address with the key and Ip address of machine where 'Ubuntu 16.04' is installed
<br>Follow these steps to install Ansible on your configuration server.
<br>ansible-box> $ sudo apt-add-repository ppa:ansible/ansible
<br>ansible-box> $ sudo apt-get update
<br>ansible-box> $ sudo apt-get install ansible
<br>3)Install Ansible on the host machine
<br>4)Run Playbook
<br>It makes use of ansible vault. When prompted for password : use pass

TESTING
<br>
PHP Virtual Box
</br>
Login into   IP of ubuntu/phpvirtualbox. Should be able to login as admin/admin
<br>
Vagrant 
Do <b>sudo</b> ssh vagrant 
as I am creating machine using <b>root</b>. This can be changed to any user in provision.yml

<br>BEST PRACTICES FOLLOWED:

<br>1)The script is Idempotent
<br>2)Sensitive data such as password is encrypted
<br>3)Two playbooks (one for configure, other for provisioning VM)
<br>4)Variables are divided into two - non encrypted and encrypted
<br>5)Maximum use of existing Ansible modules, minimal use of shell/command module, made sure that it is idempotent wherever shell/cpmmand is used	

<b>SREENCAST LINK </b>

https://www.youtube.com/watch?v=CPCnTXlayVo
